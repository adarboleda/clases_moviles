class AppRoutes {
  
}