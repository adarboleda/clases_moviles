#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\User\dev\flutter"
export "FLUTTER_APPLICATION_PATH=D:\Universidad\Semestre2-2026\Moviles\U1\py004_atomic_design"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=D:\Universidad\Semestre2-2026\Moviles\U1\py004_atomic_design\macos\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
